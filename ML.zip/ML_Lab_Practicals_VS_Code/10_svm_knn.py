import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

data = load_breast_cancer()
X = pd.DataFrame(data.data, columns=data.feature_names)
y = data.target
print("Dataset:\n", X.head())
print("\nDataset shape:", X.shape)
print("Target classes:", data.target_names)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

models = {
    "SVM": SVC(kernel="rbf"),
    "KNN": KNeighborsClassifier(n_neighbors=5)
}
scores = {}
for name, model in models.items():
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    scores[name] = accuracy_score(y_test, pred)
    print(f"\n{name} accuracy: {scores[name]:.4f}")
    print("Confusion matrix:\n", confusion_matrix(y_test, pred))
    print("Classification report:\n",
          classification_report(y_test, pred, target_names=data.target_names))

plt.bar(scores.keys(), scores.values())
plt.ylim(0, 1)
plt.ylabel("Accuracy")
plt.title("SVM vs KNN Performance")
plt.grid(axis="y")
plt.show()
