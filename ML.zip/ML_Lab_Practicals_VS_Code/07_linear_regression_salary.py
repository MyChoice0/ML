import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

data = {
    "YearsExperience": [1.1, 1.3, 1.5, 2.0, 2.2, 2.9, 3.0, 3.2, 3.7, 3.9,
                        4.0, 4.5, 4.9, 5.1, 5.3, 5.9, 6.0, 6.8, 7.1, 7.9,
                        8.2, 8.7, 9.0, 9.5, 10.3],
    "Salary": [39343, 46205, 37731, 43525, 39891, 56642, 60150, 54445,
               57189, 63218, 55794, 56957, 57081, 61111, 67938, 66029,
               83088, 81363, 93940, 101302, 113812, 109431, 105582,
               116969, 122391]
}
df = pd.DataFrame(data)
print("First 5 rows:\n", df.head())
X, y = df[["YearsExperience"]], df["Salary"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model = LinearRegression().fit(X_train, y_train)
pred = model.predict(X_test)
print("\nCoefficient:", model.coef_[0])
print("Intercept:", model.intercept_)
print("\nActual vs predicted:\n",
      pd.DataFrame({"Actual": y_test.values, "Predicted": pred}))
print("\nMAE:", mean_absolute_error(y_test, pred))
print("MSE:", mean_squared_error(y_test, pred))
print("R2:", r2_score(y_test, pred))
print("Predicted salary for 7 years:",
      model.predict(pd.DataFrame({"YearsExperience": [7]}))[0])

plt.scatter(X_train, y_train, label="Training data")
line_x = pd.DataFrame({"YearsExperience": sorted(X_train["YearsExperience"])})
plt.plot(line_x, model.predict(line_x), color="red", label="Regression line")
plt.xlabel("Years of Experience")
plt.ylabel("Salary")
plt.title("Linear Regression - Training Data")
plt.legend()
plt.show()
