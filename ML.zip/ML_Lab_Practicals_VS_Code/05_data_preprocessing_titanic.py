import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

# Put titanic.csv in this same folder. If absent, use Seaborn's copy.
try:
    df = pd.read_csv("titanic.csv")
except FileNotFoundError:
    import seaborn as sns
    print("titanic.csv not found; loading Seaborn Titanic dataset.")
    df = sns.load_dataset("titanic")
    # Convert the Seaborn version to the columns expected by this practical.
    df = df.rename(columns={"pclass": "Pclass", "survived": "Survived",
                            "age": "Age", "fare": "Fare", "sibsp": "SibSp",
                            "parch": "Parch", "embarked": "Embarked",
                            "deck": "Cabin"})
    if "PassengerId" not in df:
        df.insert(0, "PassengerId", range(1, len(df) + 1))

print("First 5 rows:")
print(df.head())
print("\nDataset information:")
df.info()
print("\nMissing values before preprocessing:")
print(df.isnull().sum())

for col in ["Age", "Fare"]:
    if col in df and df[col].isnull().any():
        df[col] = df[col].fillna(df[col].median())
if "Embarked" in df and df["Embarked"].isnull().any():
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode()[0])
if "Cabin" in df:
    df["Cabin"] = df["Cabin"].fillna("Unknown")

print("\nMissing values after selected replacements:")
print(df.isnull().sum())

features = ["Age", "Fare", "SibSp", "Parch"]
X = df[features].copy()
X = X.fillna(X.median())  # protects against differences in dataset versions
print("\nOriginal numerical data:")
print(X.head())

normalized = pd.DataFrame(MinMaxScaler().fit_transform(X), columns=features)
standardized = pd.DataFrame(StandardScaler().fit_transform(X), columns=features)
print("\nNormalized data:")
print(normalized.head())
print("\nStandardized data:")
print(standardized.head())
print("\nNormalized statistics:")
print(normalized.describe())
print("\nStandardized statistics:")
print(standardized.describe())

normalized.to_csv("normalized_titanic_data.csv", index=False)
standardized.to_csv("scaled_titanic_data.csv", index=False)
print("\nSaved normalized_titanic_data.csv and scaled_titanic_data.csv")
