import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

np.random.seed(42)
for resource in ["stopwords", "wordnet", "omw-1.4"]:
    nltk.download(resource, quiet=True)

url = ("https://raw.githubusercontent.com/likarajo/usairline_sentiment/"
       "master/Tweets.csv")
df = pd.read_csv(url)
df = df[["text", "airline_sentiment"]].dropna()
df = df.drop_duplicates(subset="text").reset_index(drop=True)
print("Dataset loaded. Tweets:", len(df))
print("\nSentiment distribution:\n", df["airline_sentiment"].value_counts())

stop_words = set(stopwords.words("english")) - {
    "no", "nor", "not", "don't", "didn't", "doesn't", "isn't",
    "wasn't", "aren't", "couldn't", "wouldn't", "won't", "haven't"
}
lemmatizer = WordNetLemmatizer()

def preprocess(text):
    text = text.lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"@\w+", " ", text)
    text = re.sub(r"[^a-z\s']", " ", text)
    words = re.findall(r"[a-z']+", text)
    words = [lemmatizer.lemmatize(w) for w in words if w not in stop_words]
    return " ".join(words)

print("\nExample preprocessing:")
print("Original:", df.loc[0, "text"])
print("Cleaned :", preprocess(df.loc[0, "text"]))

X_train, X_test, y_train, y_test = train_test_split(
    df["text"], df["airline_sentiment"], test_size=0.2,
    random_state=42, stratify=df["airline_sentiment"]
)
vectorizer = TfidfVectorizer(max_features=5000, ngram_range=(1, 2),
                             preprocessor=preprocess)
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)
print("\nTraining tweets:", len(X_train))
print("Testing tweets:", len(X_test))
print("TF-IDF training shape:", X_train_vec.shape)

log_reg = LogisticRegression(max_iter=1000, class_weight="balanced",
                             random_state=42)
log_reg.fit(X_train_vec, y_train)
y_pred = log_reg.predict(X_test_vec)

nb = MultinomialNB()
nb.fit(X_train_vec, y_train)
nb_pred = nb.predict(X_test_vec)

print("\nLogistic Regression accuracy:", accuracy_score(y_test, y_pred))
print("Naive Bayes accuracy:", accuracy_score(y_test, nb_pred))
labels = ["negative", "neutral", "positive"]
cm = confusion_matrix(y_test, y_pred, labels=labels)
print("\nConfusion matrix:\n", cm)
print("\nClassification report:\n",
      classification_report(y_test, y_pred, labels=labels))

fig, axes = plt.subplots(1, 2, figsize=(11, 4))
df["airline_sentiment"].value_counts().reindex(labels).plot(
    kind="bar", ax=axes[0], color=["red", "gray", "green"])
axes[0].set_title("Sentiment Distribution")
axes[0].set_xlabel("Sentiment")
axes[0].set_ylabel("Number of tweets")
axes[1].imshow(cm, cmap="Blues")
axes[1].set_title("Confusion Matrix")
axes[1].set_xticks(range(3), labels)
axes[1].set_yticks(range(3), labels)
for i in range(3):
    for j in range(3):
        axes[1].text(j, i, cm[i, j], ha="center", va="center")
axes[1].set_xlabel("Predicted label")
axes[1].set_ylabel("True label")
plt.tight_layout()
plt.show()

feature_names = np.array(vectorizer.get_feature_names_out())
print("\nTop 8 words for each sentiment:")
for i, label in enumerate(log_reg.classes_):
    top = np.argsort(log_reg.coef_[i])[-8:][::-1]
    print(f"{label:9s}:", ", ".join(feature_names[top]))

new_texts = [
    "The flight was amazing and the crew was very friendly",
    "Worst airline ever, my bag was lost and the flight was delayed",
    "The flight departs from Mumbai at 6 pm"
]
print("\nPredictions on new text:")
for review in new_texts:
    vec = vectorizer.transform([review])
    print(f"{log_reg.predict(vec)[0]:9s} <- {review}")
