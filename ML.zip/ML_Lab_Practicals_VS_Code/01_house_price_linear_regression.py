import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

size = np.array([500, 700, 900, 1100, 1300])
price = np.array([50, 70, 90, 110, 130])
data = pd.DataFrame({"Size": size, "Price": price})
print(data)

plt.scatter(size, price)
plt.xlabel("House Size (sq ft)")
plt.ylabel("Price (Lakhs)")
plt.title("House Size vs Price")
plt.grid(True)
plt.show()

model = LinearRegression()
model.fit(size.reshape(-1, 1), price)
house_size = float(input("Enter house size in sq ft: "))
prediction = model.predict([[house_size]])
print(f"Predicted Price: {prediction[0]:.2f} Lakhs")
