import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Seaborn downloads the Titanic sample dataset if it is not cached.
df = sns.load_dataset("titanic")
print(df.head())
print("\nShape:", df.shape)
print("\nColumns:", df.columns.tolist())
df.info()
print("\nStatistics:\n", df.describe(include="all"))
print("\nMissing values:\n", df.isnull().sum())
print("\nDuplicate rows:", df.duplicated().sum())

df["age"] = df["age"].fillna(df["age"].median())
df["embarked"] = df["embarked"].fillna(df["embarked"].mode()[0])
df = df.drop_duplicates()

sns.histplot(data=df, x="age", bins=30, kde=True)
plt.title("Distribution of Passenger Age")
plt.show()

sns.countplot(data=df, x="sex", hue="sex", legend=False)
plt.title("Number of Passengers by Gender")
plt.show()

sns.countplot(data=df, x="sex", hue="survived")
plt.title("Survival by Gender")
plt.show()

sns.countplot(data=df, x="class", hue="survived")
plt.title("Survival by Passenger Class")
plt.show()

sns.boxplot(data=df, x="class", y="fare", hue="class", legend=False)
plt.title("Fare Distribution by Passenger Class")
plt.show()

sns.scatterplot(data=df, x="age", y="fare", hue="survived")
plt.title("Age vs Fare")
plt.show()

numeric_df = df.select_dtypes(include=np.number)
sns.heatmap(numeric_df.corr(), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()

print("\nSurvival rate by gender (%):")
print(df.groupby("sex")["survived"].mean() * 100)
print("\nSurvival rate by class (%):")
print(df.groupby("class", observed=True)["survived"].mean() * 100)

q1, q3 = df["fare"].quantile([0.25, 0.75])
iqr = q3 - q1
outliers = df[(df["fare"] < q1 - 1.5 * iqr) |
              (df["fare"] > q3 + 1.5 * iqr)]
print("\nNumber of fare outliers:", len(outliers))
