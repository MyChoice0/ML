import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

iris = load_iris()
X, y = iris.data, iris.target
feature_names = iris.feature_names
X_scaled = StandardScaler().fit_transform(X)

pca_all = PCA(n_components=4)
pca_all.fit(X_scaled)
ratios = pca_all.explained_variance_ratio_
print("Eigenvalues:", pca_all.explained_variance_)
print("Explained variance ratio:", ratios)
print("Cumulative variance:", np.cumsum(ratios))
print("\nPrincipal component loadings:\n", pca_all.components_)

pca_2 = PCA(n_components=2)
X_2d = pca_2.fit_transform(X_scaled)
print("\nReduced data shape:", X_2d.shape)
print("Variance retained by 2 components:", pca_2.explained_variance_ratio_.sum())

pca_95 = PCA(n_components=0.95)
X_95 = pca_95.fit_transform(X_scaled)
print("Components needed for 95% variance:", pca_95.n_components_)

reconstructed = pca_2.inverse_transform(X_2d)
reconstruction_mse = np.mean((X_scaled - reconstructed) ** 2)
print("Reconstruction MSE using 2 components:", reconstruction_mse)

plt.plot(range(1, 5), ratios, marker="o")
plt.xlabel("Principal component")
plt.ylabel("Explained variance ratio")
plt.title("PCA Scree Plot")
plt.xticks(range(1, 5))
plt.grid(True)
plt.show()

for class_id, name in enumerate(iris.target_names):
    plt.scatter(X_2d[y == class_id, 0], X_2d[y == class_id, 1], label=name)
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.title("Iris Dataset - PCA 2D Projection")
plt.legend()
plt.grid(True)
plt.show()

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42, stratify=y
)
X_train_pca, X_test_pca, y_train_pca, y_test_pca = train_test_split(
    X_2d, y, test_size=0.2, random_state=42, stratify=y
)
original_model = LogisticRegression(max_iter=1000).fit(X_train, y_train)
pca_model = LogisticRegression(max_iter=1000).fit(X_train_pca, y_train_pca)
print("\nAccuracy with original features:",
      accuracy_score(y_test, original_model.predict(X_test)))
print("Accuracy with 2 PCA components:",
      accuracy_score(y_test_pca, pca_model.predict(X_test_pca)))
