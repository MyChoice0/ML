import pandas as pd
import matplotlib.pyplot as plt
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules

transactions = [
    ["Milk", "Bread", "Butter"], ["Milk", "Bread"],
    ["Milk", "Bread", "Butter", "Eggs"], ["Bread", "Butter"],
    ["Milk", "Eggs"], ["Milk", "Bread", "Eggs"],
    ["Bread", "Butter", "Jam"], ["Milk", "Bread", "Butter", "Jam"],
    ["Bread", "Eggs"], ["Milk", "Bread", "Butter"],
    ["Milk", "Eggs", "Bread"], ["Bread", "Butter", "Eggs"],
    ["Milk", "Bread", "Jam"], ["Milk", "Butter", "Eggs"],
    ["Bread", "Butter", "Jam", "Eggs"]
]

encoder = TransactionEncoder()
encoded = encoder.fit(transactions).transform(transactions)
basket = pd.DataFrame(encoded, columns=encoder.columns_)
print("Transaction dataset:\n", basket)

itemsets = apriori(basket, min_support=0.30, use_colnames=True)
print("\nFrequent itemsets:\n", itemsets)

# mlxtend 0.23+ expects num_itemsets as a keyword argument.
rules = association_rules(itemsets, metric="confidence",
                          min_threshold=0.60, num_itemsets=len(basket))
result = rules[["antecedents", "consequents", "support", "confidence", "lift"]]
result = result.sort_values("confidence", ascending=False)
print("\nAssociation rules:\n", result)

def readable(items):
    return ", ".join(sorted(items))

readable_rules = result.copy()
readable_rules["antecedents"] = readable_rules["antecedents"].apply(readable)
readable_rules["consequents"] = readable_rules["consequents"].apply(readable)
print("\nReadable rules:\n", readable_rules)

strong = readable_rules[(readable_rules["confidence"] >= 0.60) &
                         (readable_rules["lift"] > 1)]
print("\nStrong rules:\n", strong)

plt.scatter(result["support"], result["confidence"],
            s=100, c=result["lift"], cmap="viridis")
plt.xlabel("Support")
plt.ylabel("Confidence")
plt.title("Support vs Confidence")
plt.colorbar(label="Lift")
plt.grid(True)
plt.show()
