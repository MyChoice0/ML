import spacy

# Install model once in VS Code terminal:
# python -m spacy download en_core_web_sm
nlp = spacy.load("en_core_web_sm")
text = """
Apple Inc. was founded by Steve Jobs in California.
The company launched the iPhone in 2007.
"""
doc = nlp(text)

print("--- TOKENS ---")
for token in doc:
    print(token.text)

print("\n--- PARTS OF SPEECH ---")
for token in doc:
    print(token.text, "->", token.pos_)

print("\n--- NAMED ENTITIES ---")
for ent in doc.ents:
    print(ent.text, "->", ent.label_)
