import re
import string
from textblob import TextBlob

def show(title, value):
    print(f"\n{title}:\n{value}")

text = "Machine Learning is AMAZING! Welcome to Python."
show("Original", text)
show("Lowercase", text.lower())

text = "<h1>Welcome to Machine Learning</h1><p>This is my first practical.</p>"
show("HTML removed", re.sub(r"<.*?>", "", text))

text = "Visit https://www.google.com or www.example.com for information."
show("URLs removed", re.sub(r"https?://\S+|www\.\S+", "", text))

text = "Contact support@gmail.com or admin@yahoo.com."
show("Emails removed", re.sub(r"\S+@\S+", "", text))

text = "Hello 😊 Welcome to Machine Learning!"
show("Non-ASCII characters removed", re.sub(r"[^\x00-\x7F]+", "", text))

text = "Hello! Welcome to Machine Learning. How are you?"
show("Punctuation removed", text.translate(str.maketrans("", "", string.punctuation)))

text = "Machine Learning 2025 is used in AI 4.0 and Python 3."
show("Numbers removed", re.sub(r"\d+", "", text))

text = "Machine@Learning# is $awesome% & useful* for^ AI!"
show("Special characters removed", re.sub(r"[^a-zA-Z0-9\s]", "", text))

text = "Machine        Learning    is very       interesting."
show("Extra spaces removed", re.sub(r"\s+", " ", text).strip())

text = "I'm learning NLP. It's interesting and I can't wait."
contractions = {"I'm": "I am", "It's": "It is", "can't": "cannot",
                "don't": "do not", "won't": "will not"}
for short, full in contractions.items():
    text = text.replace(short, full)
show("Contractions expanded", text)

text = "I hav a dreem."
show("Spelling correction (TextBlob)", str(TextBlob(text).correct()))

text = "Soooo, I am happppyyyy to learn Machiiiine Leaarning!!!"
show("Repeated characters reduced", re.sub(r"(.)\1+", r"\1", text))
