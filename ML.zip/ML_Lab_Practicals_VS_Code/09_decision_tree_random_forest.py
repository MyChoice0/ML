import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df["species"] = iris.target
print("First 5 rows:\n", df.head())
X, y = iris.data, iris.target
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

dt = DecisionTreeClassifier(random_state=42).fit(X_train, y_train)
dt_pred = dt.predict(X_test)
rf = RandomForestClassifier(n_estimators=100, random_state=42).fit(X_train, y_train)
rf_pred = rf.predict(X_test)

dt_acc = accuracy_score(y_test, dt_pred)
rf_acc = accuracy_score(y_test, rf_pred)
print("\nDecision Tree accuracy:", dt_acc, f"({dt_acc*100:.2f}%)")
print("Random Forest accuracy:", rf_acc, f"({rf_acc*100:.2f}%)")
print("\nDecision Tree report:\n",
      classification_report(y_test, dt_pred, target_names=iris.target_names))
print("\nRandom Forest report:\n",
      classification_report(y_test, rf_pred, target_names=iris.target_names))

plt.figure(figsize=(14, 8))
plot_tree(dt, feature_names=iris.feature_names, class_names=iris.target_names,
          filled=True, rounded=True)
plt.title("Decision Tree - Iris")
plt.show()
