import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans, AgglomerativeClustering
from scipy.cluster.hierarchy import dendrogram, linkage

iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
print("First 5 rows:\n", df.head())
print("\nShape:", df.shape)
print("\nMissing values:\n", df.isnull().sum())
print("\nStatistics:\n", df.describe())

X_scaled = StandardScaler().fit_transform(df)
inertia = []
for k in range(1, 11):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(X_scaled)
    inertia.append(km.inertia_)

plt.plot(range(1, 11), inertia, marker="o")
plt.xlabel("Number of clusters (K)")
plt.ylabel("Inertia")
plt.title("Elbow Method")
plt.grid(True)
plt.show()

kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
k_labels = kmeans.fit_predict(X_scaled)
df["KMeans_Cluster"] = k_labels
print("\nK-Means cluster counts:\n", df["KMeans_Cluster"].value_counts().sort_index())

plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=k_labels, cmap="viridis", s=60)
plt.xlabel("Sepal Length (standardized)")
plt.ylabel("Sepal Width (standardized)")
plt.title("K-Means Clustering")
plt.colorbar(label="Cluster")
plt.grid(True)
plt.show()

linked = linkage(X_scaled, method="ward")
plt.figure(figsize=(12, 6))
dendrogram(linked)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Data points")
plt.ylabel("Euclidean distance")
plt.show()

hier = AgglomerativeClustering(n_clusters=3, linkage="ward")
h_labels = hier.fit_predict(X_scaled)
df["Hierarchical_Cluster"] = h_labels
print("\nHierarchical cluster counts:\n",
      df["Hierarchical_Cluster"].value_counts().sort_index())

plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=h_labels, cmap="viridis", s=60)
plt.xlabel("Sepal Length (standardized)")
plt.ylabel("Sepal Width (standardized)")
plt.title("Hierarchical Clustering")
plt.colorbar(label="Cluster")
plt.grid(True)
plt.show()
print("\nCluster comparison:\n",
      pd.DataFrame({"K-Means": k_labels, "Hierarchical": h_labels}).head(20))
