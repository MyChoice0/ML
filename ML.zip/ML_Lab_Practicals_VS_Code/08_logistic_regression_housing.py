import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay, classification_report

# Place Housing.csv in the project folder. It should contain a numeric 'price'
# column and optional categorical columns such as mainroad/guestroom/etc.
if not os.path.exists("Housing.csv"):
    raise FileNotFoundError(
        "Housing.csv is required. Download the housing dataset used in your lab "
        "and place Housing.csv beside this script."
    )

df = pd.read_csv("Housing.csv")
print("Columns:", df.columns.tolist())
categorical_cols = df.select_dtypes(include=["object"]).columns
df = pd.get_dummies(df, columns=categorical_cols, drop_first=True)

if "price" not in df.columns:
    raise ValueError("Housing.csv must contain a 'price' column.")

median_price = df["price"].median()
df["target"] = (df["price"] >= median_price).astype(int)
X = df.drop(["price", "target"], axis=1)
y = df["target"]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = LogisticRegression(random_state=42, max_iter=1000)
model.fit(X_train, y_train)
pred = model.predict(X_test)

acc = accuracy_score(y_test, pred)
cm = confusion_matrix(y_test, pred)
print("\nAccuracy:", acc)
print("\nConfusion matrix:\n", cm)
print("\nClassification report:\n",
      classification_report(y_test, pred, target_names=["Low Price", "High Price"]))
ConfusionMatrixDisplay(cm, display_labels=["Low Price", "High Price"]).plot(cmap="Blues")
plt.title("Logistic Regression - Housing Classification")
plt.show()
