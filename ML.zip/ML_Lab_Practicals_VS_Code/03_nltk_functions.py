import nltk
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download once; internet is needed the first time.
for resource in ["punkt", "punkt_tab", "stopwords", "wordnet", "omw-1.4"]:
    nltk.download(resource, quiet=True)

text = "Machine Learning is very interesting."
print("Original:", text)
print("Word tokens:", word_tokenize(text))

text = ("Machine Learning is very interesting. It is used in Artificial "
        "Intelligence. Python is popular.")
print("\nSentence tokens:", sent_tokenize(text))

text = "Machine Learning is very interesting and it is used in Artificial Intelligence."
words = word_tokenize(text)
stop_words = set(stopwords.words("english"))
print("\nAfter stop-word removal:",
      [w for w in words if w.lower() not in stop_words])

text = "Students are studying, playing, and learning machine learning."
words = word_tokenize(text)
stemmer = PorterStemmer()
print("\nAfter stemming:", [stemmer.stem(w) for w in words if w.isalpha()])

lemmatizer = WordNetLemmatizer()
print("After lemmatization:",
      [lemmatizer.lemmatize(w, pos="v") for w in words if w.isalpha()])
