# Machine Learning Lab Practicals — VS Code Edition

These 16 standalone `.py` files adapt the practicals in the supplied 116-page PDF for local Python execution in VS Code.

## 1. Setup (Windows PowerShell / VS Code terminal)

Open this folder in VS Code, then run:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If `py` is not recognized, use `python` instead.

### spaCy language model
Practical 4 needs the English model. Run once:

```powershell
python -m spacy download en_core_web_sm
```

NLTK downloads its small language resources automatically the first time Practicals 3 and 16 run. Internet is needed for those first downloads.

## 2. Run a practical

For example:

```powershell
python 01_house_price_linear_regression.py
```

Replace the filename with the practical you want to run. Use the VS Code terminal (not the Code Runner output panel) for programs that request keyboard input.

## 3. Dataset notes

- Practicals 1, 7, 9, 10, 11, 13 and 15 use data created in the script or datasets bundled with scikit-learn.
- Practicals 5 and 6 use Titanic data. Practical 5 first looks for `titanic.csv` in this folder; if it is absent, it loads the Seaborn Titanic sample dataset (internet may be needed the first time). Practical 6 uses Seaborn's Titanic sample dataset.
- Practical 8 requires `Housing.csv` in this folder. The PDF uses a housing-price CSV but does not include the actual CSV file. Put your copy of `Housing.csv` beside the script. It must have a `price` column.
- Practical 14 downloads CIFAR-10 automatically through Keras on first run. This is a large download and CNN training can be slow on a CPU. The script uses 10 epochs as a practical local starting point.
- Practical 16 downloads the Twitter US Airline Sentiment CSV from the public URL used in the PDF. Internet is required.

## 4. Files

| File | Practical |
|---|---|
| 01_house_price_linear_regression.py | 1 — House price Linear Regression |
| 02_text_preprocessing.py | 2 — Text preprocessing |
| 03_nltk_functions.py | 3 — NLTK functions |
| 04_spacy_library.py | 4 — spaCy |
| 05_data_preprocessing_titanic.py | 5 — Missing values, Min-Max and Standard scaling |
| 06_eda_titanic.py | 6 — EDA and visualization |
| 07_linear_regression_salary.py | 7 — Linear Regression and MAE/MSE/R² |
| 08_logistic_regression_housing.py | 8 — Logistic Regression classification |
| 09_decision_tree_random_forest.py | 9 — Decision Tree and Random Forest |
| 10_svm_knn.py | 10 — SVM and KNN |
| 11_kmeans_hierarchical.py | 11 — K-Means and Hierarchical clustering |
| 12_apriori_market_basket.py | 12 — Apriori association rules |
| 13_ann_tensorflow.py | 13 — ANN with TensorFlow/Keras |
| 14_cnn_cifar10.py | 14 — CNN with CIFAR-10 |
| 15_pca_dimensionality_reduction.py | 15 — PCA |
| 16_sentiment_analysis.py | 16 — NLP sentiment analysis |

## 5. Notes about adaptation

- Removed notebook-only commands such as `!pip install`.
- Removed machine-specific absolute Windows file paths where possible.
- Added dataset checks and clear error messages.
- Fixed indentation and imports where the PDF's extracted formatting had merged lines.
- In Practical 12, included the `num_itemsets` argument accepted by recent mlxtend releases.
- In Practical 16, preprocessing is applied inside the TF-IDF vectorizer, and the vectorizer is fit only on training text to avoid test-data leakage.
- Results can differ slightly across package versions, train/test splits, and CPU/GPU environments. Record the values produced by your own run.

## 6. TensorFlow note

TensorFlow is the largest and most platform-sensitive dependency. If its installation fails on your Python version, create the environment with a Python version supported by the TensorFlow release available for your operating system, then install `tensorflow` separately. Avoid installing packages into a different Python interpreter than the one selected in VS Code.
